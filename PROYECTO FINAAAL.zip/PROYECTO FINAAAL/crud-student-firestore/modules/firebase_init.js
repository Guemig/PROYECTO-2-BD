import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore, collection, addDoc, getDocs } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

// Configuración de Firebase
const firebaseConfig = {
  apiKey: "AIzaSyAJLwPotLQODCP-aSu33d8j6ujGnL_auoU",
  authDomain: "test-gym-sdo-corte.firebaseapp.com",
  projectId: "test-gym-sdo-corte",
  storageBucket: "test-gym-sdo-corte.firebasestorage.app",
  messagingSenderId: "240924685368",
  appId: "1:240924685368:web:4677bf3dbba98a6f4ba2cd",
  measurementId: "G-QJ7QCZSNQY"
};
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const db = getFirestore(app); // 👈 NECESARIO para usar Firestore

export class FirestoreQuery {
  constructor(collectionName) {
      this.collectionRef = collection(db, collectionName);
      this.ensureTestData(); // Agrega datos si la colección está vacía
  }

  async saveDocument(data) {
      return await addDoc(this.collectionRef, data);
  }

  async getAllDocuments() {
      const snapshot = await getDocs(this.collectionRef);
      return snapshot.docs.map(doc => doc.data());
  }

  randomInRange(min, max) {
      return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  randomDate(start, end) {
      const date = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
      return date.toISOString().split('T')[0];
  }

  randomTime() {
      const h = String(this.randomInRange(0, 2)).padStart(2, '0');
      const m = String(this.randomInRange(0, 59)).padStart(2, '0');
      const s = String(this.randomInRange(0, 59)).padStart(2, '0');
      return `${h}:${m}:${s}`;
  }

  async ensureTestData() {
      const docs = await this.getAllDocuments();
      if (docs.length >= 200) return;

      const promises = [];

      for (let i = 0; i < 200; i++) {
          const data = {
              Player_idPlayer: this.randomInRange(1, 50),
              Score_idScore: this.randomInRange(100, 1000),
              Level_idLevel: this.randomInRange(1, 10),
              Date: this.randomDate(new Date(2023, 0, 1), new Date()),
              Time: this.randomTime()
          };
          promises.push(this.saveDocument(data));
      }

      await Promise.all(promises);
      console.log("✅ Se generaron 200 partidas aleatorias automáticamente.");
  }
}