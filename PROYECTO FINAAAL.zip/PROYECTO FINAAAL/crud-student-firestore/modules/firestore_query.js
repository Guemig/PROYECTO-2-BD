// firestore_query.js
import { db } from './firebase_init.js';
import {
    collection,
    addDoc,
    getDocs
} from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

export class FirestoreQuery {
    constructor(collectionName) {
        this.collectionRef = collection(db, collectionName);
    }

    async saveDocument(data) {
        try {
            const docRef = await addDoc(this.collectionRef, data);
            console.log("✅ Documento guardado con ID:", docRef.id);
        } catch (error) {
            console.error("❌ Error al guardar el documento:", error);
            throw error;
        }
    }

    async getAllDocuments() {
        const snapshot = await getDocs(this.collectionRef);
        return snapshot.docs.map(doc => doc.data());
    }
}
