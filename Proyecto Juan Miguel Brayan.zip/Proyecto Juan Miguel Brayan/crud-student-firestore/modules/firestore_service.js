import { db } from './firebase_init.js';
import { collection, getDocs, getDoc, setDoc, doc } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

export class FirestoreService {

  constructor() {
    
  }

  async getAllDocuments(collectionName) {
    const colRef = collection(db, collectionName);
    const snapshot = await getDocs(colRef);
    const data = [];
    snapshot.forEach((doc) => {
      data.push({ id: doc.id, ...doc.data() });
    });
    return data;
  }

  async getDocumentById(collectionName, id) {
    const docRef = doc(db, collectionName, id);
    const snapshot = await getDoc(docRef);

    if (snapshot.exists()) {
      return { id: snapshot.id, ...snapshot.data() };
    } else {
      return null;
    }
  }

  async PostDocument(collectionName, customId, dataObject) {
    try {
      console.log(`Saving to [${collectionName}] ID: ${customId}`, dataObject);
      const docRef = doc(db, collectionName, customId.toString());
      await setDoc(docRef, dataObject);
      console.log("Documento creado con ID:", customId);
      alert(`Documento guardado en ${collectionName} correctamente.`);
    } catch (e) {
      console.error(`Error al guardar en ${collectionName}:`, e);
      alert("Error al crear el documento.");
    }
  }
}
