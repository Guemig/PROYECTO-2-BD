// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAJLwPotLQODCP-aSu33d8j6ujGnL_auoU",
  authDomain: "test-gym-sdo-corte.firebaseapp.com",
  projectId: "test-gym-sdo-corte",
  storageBucket: "test-gym-sdo-corte.firebasestorage.app",
  messagingSenderId: "240924685368",
  appId: "1:240924685368:web:4677bf3dbba98a6f4ba2cd",
  measurementId: "G-QJ7QCZSNQY"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);